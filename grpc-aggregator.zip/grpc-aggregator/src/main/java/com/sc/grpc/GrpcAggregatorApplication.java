package com.sc.grpc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrpcAggregatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrpcAggregatorApplication.class, args);
	}

}
